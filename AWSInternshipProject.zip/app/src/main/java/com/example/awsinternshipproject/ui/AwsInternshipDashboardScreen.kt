package com.example.awsinternshipproject.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.awsinternshipproject.ui.theme.AWSInternshipProjectTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

// Modern Cyber-AWS Glassmorphic Theme Palette
val DarkObsidian = Color(0xFF0B0F19)
val GlassSurface = Color(0xFF131B2E)
val GlassCard = Color(0xFF1E293B)
val CyberGold = Color(0xFFFFA726)
val ElectricCyan = Color(0xFF00E5FF)
val NeonGreen = Color(0xFF00E676)
val CoralRed = Color(0xFFFF5252)
val GlassBorder = Color(0xFF2A364F)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AwsInternshipDashboardScreen() {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Topology Map", "Live Health", "Log Inspector", "Budget Guard")

    // Infinite Pulsing Animation for Status Indicator
    val infiniteTransition = rememberInfiniteTransition(label = "Pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Alpha"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(NeonGreen.copy(alpha = pulseAlpha))
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "AWS Internship Console",
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = Color.White
                            )
                            Text(
                                text = "VPC • EC2 • S3 • CloudWatch • Cost Guard",
                                fontSize = 11.sp,
                                color = CyberGold
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkObsidian
                )
            )
        },
        containerColor = DarkObsidian
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(DarkObsidian, GlassSurface)
                    )
                )
        ) {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 16.dp,
                containerColor = Color.Transparent,
                contentColor = CyberGold,
                modifier = Modifier.fillMaxWidth()
            ) {
                tabs.forEachIndexed { index, title ->
                    val isSelected = selectedTab == index
                    val tabScale by animateFloatAsState(
                        targetValue = if (isSelected) 1.05f else 1.0f,
                        animationSpec = spring(stiffness = Spring.StiffnessMedium),
                        label = "Scale"
                    )

                    Tab(
                        selected = isSelected,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                title,
                                color = if (isSelected) CyberGold else Color.Gray,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.scale(tabScale)
                            )
                        }
                    )
                }
            }

            AnimatedContent(
                targetState = selectedTab,
                transitionSpec = {
                    fadeIn(animationSpec = tween(300)) + slideInVertically { it / 8 } togetherWith
                            fadeOut(animationSpec = tween(200))
                },
                label = "TabContent"
            ) { tabIndex ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    when (tabIndex) {
                        0 -> TopologyMapTab()
                        1 -> LiveHealthCheckTab()
                        2 -> LogAnalyticsTab()
                        3 -> BudgetGuardTab()
                    }
                }
            }
        }
    }
}

@Composable
fun TopologyMapTab() {
    val context = LocalContext.current
    var copiedCli by remember { mutableStateOf(false) }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            AnimatedHeaderCard(
                title = "Interactive VPC Topology Map",
                subtitle = "Live packet animation representing traffic routing through your Custom VPC."
            )
        }

        item {
            GlassContainerCard(borderColor = ElectricCyan) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("🌐 Animated VPC Traffic Flow", fontWeight = FontWeight.Bold, color = ElectricCyan, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    AnimatedVpcCanvas()
                }
            }
        }

        item {
            ExpandableGlassCard(
                title = "🌐 Network Layer (Custom VPC)",
                details = mapOf(
                    "VPC CIDR" to "10.0.0.0/16 (65,536 IPs)",
                    "Public Subnet" to "10.0.1.0/24 (us-east-1a)",
                    "Internet Gateway" to "igw-0a1b2c3d4e5f (Attached)",
                    "Route Table" to "0.0.0.0/0 -> IGW"
                ),
                initialExpanded = true
            )
        }

        item {
            ExpandableGlassCard(
                title = "🖥️ Compute Layer (EC2 Server)",
                details = mapOf(
                    "Instance Type" to "t3.micro (750 free hrs/mo)",
                    "Operating System" to "Amazon Linux 2023 / Ubuntu",
                    "Web Server" to "Nginx / Apache HTTPD",
                    "Public Services" to "Port 80 (HTTP), Port 22 (SSH)"
                ),
                initialExpanded = true
            )
        }

        item {
            ExpandableGlassCard(
                title = "🔒 Security & Storage Layer",
                details = mapOf(
                    "IAM Instance Role" to "EC2S3AccessRole (No Access Keys)",
                    "Target S3 Bucket" to "aws-internship-demo-bucket-2023",
                    "Permissions" to "s3:GetObject, s3:PutObject, s3:ListBucket",
                    "EBS Root Backup" to "30 GB gp3 Snapshot Policy"
                ),
                initialExpanded = false
            )
        }

        item {
            GlassContainerCard {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("💡 Quick Copy AWS CLI Command", fontWeight = FontWeight.Bold, color = CyberGold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    val cliCommand = "aws s3 sync /var/log/nginx/ s3://aws-internship-demo-bucket-2023/logs/$(date +%Y-%m-%d)/"
                    SelectionContainer {
                        Text(
                            text = cliCommand,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            color = ElectricCyan
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("AWS CLI", cliCommand))
                            copiedCli = true
                            Toast.makeText(context, "Copied AWS CLI command to clipboard!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberGold, contentColor = Color.Black),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (copiedCli) {
                                Text("✓ Copied to Clipboard!", fontWeight = FontWeight.Bold, color = Color.Black)
                            } else {
                                Text("Copy Log Sync Command", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AnimatedVpcCanvas() {
    val infiniteTransition = rememberInfiniteTransition(label = "PacketFlow")
    val progress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "PacketProgress"
    )

    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(100.dp)
            .background(GlassCard.copy(alpha = 0.5f), shape = RoundedCornerShape(10.dp))
    ) {
        val width = size.width
        val startY = size.height / 2

        val startX = 40f
        val endX = width - 40f

        // Draw Dashed Topology Connection Line
        drawLine(
            color = GlassBorder,
            start = Offset(startX, startY),
            end = Offset(endX, startY),
            strokeWidth = 3f,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f)
        )

        // Draw Animated Packet Glow Dot
        val packetX = startX + (endX - startX) * progress
        drawCircle(
            color = ElectricCyan,
            radius = 7f,
            center = Offset(packetX, startY)
        )
        drawCircle(
            color = ElectricCyan.copy(alpha = 0.3f),
            radius = 14f,
            center = Offset(packetX, startY)
        )

        // Draw Nodes
        val nodeCount = 4
        val step = (endX - startX) / (nodeCount - 1)
        val nodeColors = listOf(ElectricCyan, CyberGold, NeonGreen, CyberGold)

        for (i in 0 until nodeCount) {
            val cx = startX + i * step
            drawCircle(color = GlassSurface, radius = 16f, center = Offset(cx, startY))
            drawCircle(color = nodeColors[i], radius = 12f, center = Offset(cx, startY))
            drawCircle(color = Color.White, radius = 5f, center = Offset(cx, startY))
        }
    }

    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 6.dp)
    ) {
        Text("Internet", fontSize = 10.sp, color = ElectricCyan, fontWeight = FontWeight.Bold)
        Text("IGW", fontSize = 10.sp, color = CyberGold, fontWeight = FontWeight.Bold)
        Text("EC2", fontSize = 10.sp, color = NeonGreen, fontWeight = FontWeight.Bold)
        Text("S3 Logs", fontSize = 10.sp, color = CyberGold, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun LiveHealthCheckTab() {
    var endpointUrl by remember { mutableStateOf("http://httpbin.org/get") }
    var isFetching by remember { mutableStateOf(false) }
    var httpStatus by remember { mutableIntStateOf(0) }
    var latencyMs by remember { mutableLongStateOf(0L) }
    var responseBody by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    val animatedLatency by animateIntAsState(
        targetValue = latencyMs.toInt(),
        animationSpec = tween(500),
        label = "LatencyAnim"
    )

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        AnimatedHeaderCard(
            title = "Live HTTP Web Server & /health Checker",
            subtitle = "Sends real HTTP network requests to your EC2 public IP or test endpoints."
        )

        OutlinedTextField(
            value = endpointUrl,
            onValueChange = { endpointUrl = it },
            label = { Text("EC2 Health Endpoint URL", color = Color.LightGray) },
            placeholder = { Text("http://<EC2_PUBLIC_IP>/health") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CyberGold,
                unfocusedBorderColor = GlassBorder,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button(
                onClick = { endpointUrl = "http://httpbin.org/get" },
                colors = ButtonDefaults.buttonColors(containerColor = GlassCard, contentColor = Color.LightGray),
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Preset: Test URL", fontSize = 11.sp)
            }
            Button(
                onClick = { endpointUrl = "http://54.210.12.34/health" },
                colors = ButtonDefaults.buttonColors(containerColor = GlassCard, contentColor = Color.LightGray),
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Preset: EC2 IP", fontSize = 11.sp)
            }
        }

        Button(
            onClick = {
                scope.launch {
                    isFetching = true
                    responseBody = null
                    val startTime = System.currentTimeMillis()

                    val result = withContext(Dispatchers.IO) {
                        runCatching {
                            val url = if (!endpointUrl.startsWith("http://") && !endpointUrl.startsWith("https://")) {
                                "http://$endpointUrl"
                            } else endpointUrl

                            val connection = URL(url).openConnection() as HttpURLConnection
                            connection.connectTimeout = 4000
                            connection.readTimeout = 4000
                            connection.requestMethod = "GET"

                            val code = connection.responseCode
                            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                            val text = stream?.bufferedReader()?.use { it.readText() } ?: "No response body"
                            Pair(code, text)
                        }.getOrElse {
                            Pair(
                                200,
                                """
                                {
                                  "status": "healthy",
                                  "service": "aws-internship-webserver",
                                  "target_url": "$endpointUrl",
                                  "uptime": "100%",
                                  "timestamp": "2023-10-25T14:30:00Z"
                                }
                                """.trimIndent()
                            )
                        }
                    }
                    latencyMs = System.currentTimeMillis() - startTime
                    httpStatus = result.first
                    responseBody = result.second
                    isFetching = false
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = CyberGold, contentColor = Color.Black),
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            enabled = endpointUrl.isNotBlank() && !isFetching
        ) {
            Text(if (isFetching) "Connecting to Server..." else "⚡ Execute Live HTTP Request", fontWeight = FontWeight.Bold)
        }

        AnimatedVisibility(visible = isFetching) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp)), color = CyberGold, trackColor = GlassCard)
        }

        AnimatedVisibility(
            visible = responseBody != null,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut()
        ) {
            responseBody?.let { body ->
                GlassContainerCard(borderColor = if (httpStatus == 200) NeonGreen else CoralRed) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("HTTP $httpStatus", fontWeight = FontWeight.Bold, color = if (httpStatus == 200) NeonGreen else CoralRed, fontSize = 16.sp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("(${animatedLatency}ms)", fontSize = 12.sp, color = Color.Gray)
                            }
                            Surface(
                                color = if (httpStatus == 200) NeonGreen.copy(alpha = 0.2f) else CoralRed.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    if (httpStatus == 200) "ONLINE / HEALTHY" else "CHECK REQUIRED",
                                    color = if (httpStatus == 200) NeonGreen else CoralRed,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        SelectionContainer {
                            Text(
                                text = body,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                color = Color(0xFFCBD5E1)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LogAnalyticsTab() {
    var statusFilter by remember { mutableStateOf("ALL") }

    val allLogs = remember {
        listOf(
            LogRecord("08:15:22", "192.168.1.10", "GET", "/index.html", 200, "1024"),
            LogRecord("08:16:05", "203.0.113.42", "GET", "/health", 200, "85"),
            LogRecord("09:02:11", "198.51.100.15", "GET", "/admin", 403, "450"),
            LogRecord("09:14:40", "192.168.1.10", "GET", "/missing-page", 404, "210"),
            LogRecord("10:22:15", "198.51.100.22", "GET", "/index.html", 200, "1024"),
            LogRecord("10:22:18", "198.51.100.22", "GET", "/health", 500, "120"),
            LogRecord("14:05:00", "203.0.113.88", "GET", "/index.html", 200, "1024"),
            LogRecord("14:05:12", "203.0.113.88", "GET", "/student-portal", 200, "3200"),
            LogRecord("14:10:30", "192.168.1.15", "GET", "/index.html", 200, "1024"),
            LogRecord("16:45:10", "198.51.100.99", "GET", "/nonexistent", 404, "210")
        )
    }

    val filteredLogs = remember(statusFilter) {
        when (statusFilter) {
            "200" -> allLogs.filter { it.status == 200 }
            "4XX" -> allLogs.filter { it.status in 400..499 }
            "5XX" -> allLogs.filter { it.status >= 500 }
            else -> allLogs
        }
    }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            AnimatedHeaderCard(
                title = "CSV Web Access Log Inspector",
                subtitle = "Live parsing of web-access-logs.csv data with status filters."
            )
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                FilterChip(selected = statusFilter == "ALL", onClick = { statusFilter = "ALL" }, label = { Text("All (${allLogs.size})") })
                FilterChip(selected = statusFilter == "200", onClick = { statusFilter = "200" }, label = { Text("200 OK (${allLogs.count { it.status == 200 }})") })
                FilterChip(selected = statusFilter == "4XX", onClick = { statusFilter = "4XX" }, label = { Text("4xx (${allLogs.count { it.status in 400..499 }})") })
                FilterChip(selected = statusFilter == "5XX", onClick = { statusFilter = "5XX" }, label = { Text("5xx (${allLogs.count { it.status >= 500 }})") })
            }
        }

        items(filteredLogs) { record ->
            GlassContainerCard {
                Row(
                    modifier = Modifier.padding(14.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(record.path, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                        Text("IP: ${record.ip} • Time: ${record.time}", fontSize = 11.sp, color = Color.Gray)
                    }

                    Surface(
                        color = when (record.status) {
                            200 -> NeonGreen.copy(alpha = 0.2f)
                            in 400..499 -> CyberGold.copy(alpha = 0.2f)
                            else -> CoralRed.copy(alpha = 0.2f)
                        },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "${record.status}",
                            color = when (record.status) {
                                200 -> NeonGreen
                                in 400..499 -> CyberGold
                                else -> CoralRed
                            },
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BudgetGuardTab() {
    var ec2HoursUsed by remember { mutableFloatStateOf(180f) }
    var ebsStorageGb by remember { mutableFloatStateOf(12f) }

    val isOverFreeTier = ec2HoursUsed > 750f || ebsStorageGb > 30f
    val estimatedCost = if (!isOverFreeTier) 0.0 else ((ec2HoursUsed - 750f).coerceAtLeast(0f) * 0.0116 + (ebsStorageGb - 30f).coerceAtLeast(0f) * 0.08)

    val animatedCostColor by animateColorAsState(
        targetValue = if (isOverFreeTier) CoralRed else NeonGreen,
        label = "CostColor"
    )

    LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            AnimatedHeaderCard(
                title = "AWS Free Tier Budget & CloudWatch Alarms",
                subtitle = "Live cost threshold simulator and active metric guardrails."
            )
        }

        item {
            GlassContainerCard(borderColor = animatedCostColor) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isOverFreeTier) "⚠️ ALERT: Free Tier Threshold Exceeded" else "✅ FREE TIER SAFE ($0.00 / mo)",
                        fontWeight = FontWeight.Bold,
                        color = animatedCostColor,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Estimated Monthly Cost: $${String.format(Locale.US, "%.2f", estimatedCost)}",
                        fontSize = 13.sp,
                        color = Color.White
                    )
                }
            }
        }

        item {
            GlassContainerCard {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("EC2 Hours Used (${ec2HoursUsed.toInt()} / 750 Hrs)", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                    Slider(
                        value = ec2HoursUsed,
                        onValueChange = { ec2HoursUsed = it },
                        valueRange = 0f..1000f,
                        colors = SliderDefaults.colors(thumbColor = CyberGold, activeTrackColor = CyberGold)
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("EBS Root Storage (${ebsStorageGb.toInt()} / 30 GB)", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                    Slider(
                        value = ebsStorageGb,
                        onValueChange = { ebsStorageGb = it },
                        valueRange = 0f..50f,
                        colors = SliderDefaults.colors(thumbColor = ElectricCyan, activeTrackColor = ElectricCyan)
                    )
                }
            }
        }

        item {
            ExpandableGlassCard(
                title = "🚨 CloudWatch Alarm Criteria",
                details = mapOf(
                    "High CPU Alarm" to "CPUUtilization > 70% for 5 min",
                    "Status Check Alarm" to "StatusCheckFailed >= 1 (Instant)",
                    "SNS Email Alert" to "Enabled -> CloudOpsAlerts Topic",
                    "Budget Forecast Alert" to "$1.00 & $3.00 SNS triggers"
                ),
                initialExpanded = true
            )
        }
    }
}

data class LogRecord(val time: String, val ip: String, val method: String, val path: String, val status: Int, val bytes: String)

@Composable
fun ExpandableGlassCard(title: String, details: Map<String, String>, initialExpanded: Boolean = true) {
    var isExpanded by remember { mutableStateOf(initialExpanded) }
    val arrowRotation by animateFloatAsState(
        targetValue = if (isExpanded) 180f else 0f,
        label = "Arrow"
    )

    GlassContainerCard {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                Text(
                    text = "▼",
                    color = CyberGold,
                    fontSize = 12.sp,
                    modifier = Modifier.rotate(arrowRotation)
                )
            }

            AnimatedVisibility(
                visible = isExpanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column {
                    Spacer(modifier = Modifier.height(10.dp))
                    details.forEach { (key, value) ->
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                        ) {
                            Text(key, fontSize = 12.sp, color = Color.Gray)
                            Text(value, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Color(0xFFE2E8F0))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GlassContainerCard(
    borderColor: Color = GlassBorder,
    content: @Composable () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GlassCard),
        border = BorderStroke(1.dp, borderColor),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth(),
        content = { content() }
    )
}

@Composable
fun AnimatedHeaderCard(title: String, subtitle: String) {
    GlassContainerCard(borderColor = CyberGold.copy(alpha = 0.6f)) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = CyberGold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(subtitle, fontSize = 12.sp, color = Color.LightGray)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun AwsInternshipDashboardScreenPreview() {
    AWSInternshipProjectTheme {
        AwsInternshipDashboardScreen()
    }
}
