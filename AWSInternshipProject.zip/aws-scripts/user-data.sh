#!/bin/bash
set -e

# Update package manager and install Nginx & AWS CLI
apt-get update -y || dnf update -y
if command -v apt-get &> /dev/null; then
    apt-get install -y nginx awscli
else
    dnf install -y nginx awscli
fi

systemctl enable nginx
systemctl start nginx

# Create Student Portal Landing Page
cat << 'EOF' > /var/www/html/index.html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AWS Cloud Internship Project</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #eef2f7; margin: 0; padding: 50px; text-align: center; }
        .container { background: white; max-width: 650px; margin: 0 auto; padding: 40px; border-radius: 12px; box-shadow: 0 6px 15px rgba(0,0,0,0.1); }
        h1 { color: #232f3e; }
        .badge { background: #ff9900; color: white; padding: 6px 14px; border-radius: 20px; font-weight: bold; display: inline-block; margin-bottom: 20px; }
        .info { text-align: left; background: #f8f9fa; padding: 15px; border-radius: 6px; margin-top: 20px; font-family: monospace; font-size: 14px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="badge">AWS Free Tier Architecture</div>
        <h1>Student Portal & Internship Demo</h1>
        <p>Successfully deployed on a custom VPC, EC2 t3.micro instance, and secured with IAM least-privilege roles.</p>
        <div class="info">
            <strong>Architecture:</strong> Custom VPC -> Public Subnet -> IGW<br>
            <strong>Storage:</strong> EBS Root Volume & S3 Log Archiving<br>
            <strong>Monitoring:</strong> CloudWatch Alarms & SNS Alerts
        </div>
    </div>
</body>
</html>
EOF

# Configure JSON Health Endpoint
mkdir -p /var/www/html/health
cat << 'EOF' > /var/www/html/health/index.html
{
  "status": "healthy",
  "service": "internship-web-app",
  "uptime": "active",
  "timestamp": "'"$(date -u +"%Y-%m-%dT%H:%M:%SZ")"'"
}
EOF

cat << 'EOF' > /etc/nginx/conf.d/health.conf
server {
    listen 80;
    server_name _;

    location / {
        root /var/www/html;
        index index.html;
    }

    location /health {
        default_type application/json;
        alias /var/www/html/health/index.html;
    }
}
EOF

nginx -t && systemctl reload nginx
