#!/usr/bin/env python3
import csv
from collections import Counter
from datetime import datetime
import sys

def analyze_logs(filepath):
    ip_counter = Counter()
    path_counter = Counter()
    error_counter = Counter()
    hour_counter = Counter()
    total_requests = 0

    try:
        with open(filepath, mode='r', encoding='utf-8') as f:
            reader = csv.reader(f)
            for row in reader:
                if len(row) < 5:
                    continue
                timestamp, ip, method, path, status, size, agent = [x.strip() for x in row]
                total_requests += 1
                ip_counter[ip] += 1
                path_counter[path] += 1

                if status.isdigit() and 400 <= int(status) < 600:
                    error_counter[status] += 1

                try:
                    dt = datetime.strptime(timestamp.split('.')[0], "%Y-%m-%d %H:%M:%S")
                    hour_counter[dt.hour] += 1
                except ValueError:
                    pass
    except FileNotFoundError:
        print(f"File {filepath} not found.")
        sys.exit(1)

    print("=" * 60)
    print("         AWS WEB APPLICATION LOG ANALYTICS REPORT         ")
    print("=" * 60)
    print(f"Total Requests Analyzed: {total_requests}\n")

    print("1. Top Requested Pages:")
    for path, count in path_counter.most_common(5):
        print(f"   {path}: {count} requests")

    print("\n2. 4xx / 5xx Error Summary:")
    if error_counter:
        for code, count in sorted(error_counter.items()):
            print(f"   HTTP Status {code}: {count} occurrences")
    else:
        print("   No errors recorded.")

    print("\n3. Peak Traffic Hour:")
    peak_hour, peak_count = hour_counter.most_common(1)[0]
    print(f"   Hour {peak_hour:02d}:00 with {peak_count} requests")

    print("\n4. Unique Visitor IPs:")
    for ip, count in ip_counter.most_common(5):
        print(f"   IP: {ip} ({count} requests)")
    print("=" * 60)

if __name__ == "__main__":
    analyze_logs(sys.argv[1] if len(sys.argv) > 1 else "web-access-logs.csv")
