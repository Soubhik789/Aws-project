# AWS Internship Project: Production-Ready Implementation Blueprint

This implementation blueprint serves as your complete technical guide and architectural specification for your AWS Internship Project. Every component has been meticulously designed to satisfy moderate complexity standards while maintaining strict compliance with the **AWS Free Tier**.

---

## 1. System Architecture Layout & Logical Flow Mapping

```mermaid
graph TD
    User["Developer / End User"] -->|HTTP / HTTPS| IGW["Internet Gateway (igw-demo)"]
    Admin["IAM Admin / Interns"] -->|AWS Console / CLI| IAM["IAM Groups & Instance Role"]

    subgraph AWS Cloud - Custom VPC (10.0.0.0/16)
        IGW --> RT["Public Route Table (0.0.0.0/0 -> IGW)"]
        RT --> Subnet["Public Subnet (10.0.1.0/24)"]
        Subnet --> SG["Security Group (Port 80, 22)"]
        SG --> EC2["EC2 t3.micro Instance (Ubuntu/AL2023)"]
    end

    EC2 -->|IAM Instance Profile| S3["S3 Bucket (Logs & Static Assets)"]
    EC2 -->|Metrics & Alarms| CW["CloudWatch (CPU & Status Checks)"]
    CW -->|SNS Topic| Email["Admin Email Alerts"]
    EBS["EBS Root Volume"] -->|Manual Snapshot| Snapshot["EBS Snapshot Backup"]
```

### Logical Flow:
1. **Networking:** Inbound traffic reaches the Internet Gateway, routes through the Public Route Table, passes the Security Group, and hits the EC2 instance residing in the Public Subnet.
2. **Security:** EC2 assumes an IAM Instance Profile (avoiding hardcoded keys) to securely read/write to S3.
3. **Monitoring & Alerting:** CloudWatch monitors instance health and CPU utilization, triggering an SNS email notification if thresholds are breached.
4. **Cost & Backup:** AWS Budgets monitors spending while manual EBS snapshots secure root volume states.

---

## 2. IAM Role & Policy Documentation

### Least-Privilege EC2 Instance Policy (`EC2S3AccessPolicy`)
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowBucketListing",
      "Effect": "Allow",
      "Action": [
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::aws-internship-demo-bucket-2023"
      ]
    },
    {
      "Sid": "AllowObjectReadWrite",
      "Effect": "Allow",
      "Action": [
        "s3:GetObject",
        "s3:PutObject"
      ],
      "Resource": [
        "arn:aws:s3:::aws-internship-demo-bucket-2023/*"
      ]
    }
  ]
}
```

### IAM Group Structure
* **`InternDevelopers` Group:**
  * Attached Managed Policy: `AmazonEC2ReadOnlyAccess`, `AmazonS3ReadOnlyAccess`
  * Purpose: Allows interns to inspect compute and storage resources without modification rights.
* **`CloudOperators` Group:**
  * Attached Custom Policy: Full operational rights to EC2, CloudWatch, and S3 for deployment and monitoring.
  * Purpose: Handles server lifecycle management and log archiving.

> [!IMPORTANT]
> **Why IAM Instance Roles over Hardcoded Keys:** Hardcoding AWS credentials (`AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY`) in configuration files or code repositories introduces severe security risks. If compromised, attackers gain full account access. IAM Instance Roles utilize temporary security tokens managed automatically by the AWS metadata service (`169.254.169.254`), eliminating credential storage risks and enabling automatic rotation.

---

## 3. Network Configuration Matrices

| Component Resource | Parameter / Specification | Free Tier Compliance Note |
| :--- | :--- | :--- |
| **VPC** | CIDR: `10.0.0.0/16` | Free of charge (VPCs incur no base cost). |
| **Public Subnet** | CIDR: `10.0.1.0/24` (AZ: `us-east-1a`) | Single AZ ensures no cross-AZ data transfer fees. |
| **Internet Gateway** | Attached to VPC (`igw-demo`) | Free component for public internet routing. |
| **Route Table** | Route: `0.0.0.0/0` $\rightarrow$ `igw-demo` | Direct internet access without expensive NAT Gateways ($0.045/hr saved). |
| **Security Group** | Inbound: Port 80 (HTTP), Port 22 (SSH) | Restricted SSH minimizes brute-force exposure. |

---

## 4. Web Server & Endpoint Definitions

### EC2 User Data Initialization Script (Bash)
```bash
#!/bin/bash
set -e

# Update package manager and install Nginx
apt-get update -y || dnf update -y
if command -v apt-get &> /dev/null; then
    apt-get install -y nginx awscli
else
    dnf install -y nginx awscli
fi

systemctl enable nginx
systemctl start nginx

# Create Student Portal Landing Page
cat << 'EOF' > /var/www/html/index.html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AWS Cloud Internship Project</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #eef2f7; margin: 0; padding: 50px; text-align: center; }
        .container { background: white; max-width: 650px; margin: 0 auto; padding: 40px; border-radius: 12px; box-shadow: 0 6px 15px rgba(0,0,0,0.1); }
        h1 { color: #232f3e; }
        .badge { background: #ff9900; color: white; padding: 6px 14px; border-radius: 20px; font-weight: bold; display: inline-block; margin-bottom: 20px; }
        .info { text-align: left; background: #f8f9fa; padding: 15px; border-radius: 6px; margin-top: 20px; font-family: monospace; font-size: 14px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="badge">AWS Free Tier Architecture</div>
        <h1>Student Portal & Internship Demo</h1>
        <p>Successfully deployed on a custom VPC, EC2 t3.micro instance, and secured with IAM least-privilege roles.</p>
        <div class="info">
            <strong>Architecture:</strong> Custom VPC -> Public Subnet -> IGW<br>
            <strong>Storage:</strong> EBS Root Volume & S3 Log Archiving<br>
            <strong>Monitoring:</strong> CloudWatch Alarms & SNS Alerts
        </div>
    </div>
</body>
</html>
EOF

# Configure JSON Health Endpoint
mkdir -p /var/www/html/health
cat << 'EOF' > /var/www/html/health/index.html
{
  "status": "healthy",
  "service": "internship-web-app",
  "uptime": "active",
  "timestamp": "'"$(date -u +"%Y-%m-%dT%H:%M:%SZ")"'"
}
EOF

cat << 'EOF' > /etc/nginx/conf.d/health.conf
server {
    listen 80;
    server_name _;

    location / {
        root /var/www/html;
        index index.html;
    }

    location /health {
        default_type application/json;
        alias /var/www/html/health/index.html;
    }
}
EOF

nginx -t && systemctl reload nginx
```

---

## 5. S3 Structure and Data Lifecycle Plans

### S3 Bucket Structure
```text
s3://aws-internship-demo-bucket-2023/
├── assets/
│   ├── css/
│   └── images/
└── logs/
    └── 2023-10-25/
        └── access_log.csv
```

### AWS CLI Command for Automated Log Sync
Run this script via cron on your EC2 instance daily at midnight to archive Nginx access logs to S3:
```bash
#!/bin/bash
CURRENT_DATE=$(date -u +"%Y-%m-%d")
LOG_DIR="/var/log/nginx"
S3_BUCKET="s3://aws-internship-demo-bucket-2023/logs/$CURRENT_DATE/"

# Copy access logs to S3 with timestamped path
aws s3 cp $LOG_DIR/access.log "$S3_BUCKET/access_$CURRENT_DATE.log"
```

---

## 6. The Python Log Analytics Code & Mock Dataset

### Sample Dataset: `web-access-logs.csv`
```csv
timestamp,ip,method,path,status,bytes,user_agent
2023-10-25 08:15:22,192.168.1.10,GET,/index.html,200,1024,Mozilla/5.0
2023-10-25 08:16:05,203.0.113.42,GET,/health,200,85,Mozilla/5.0
2023-10-25 09:02:11,198.51.100.15,GET,/admin,403,450,Mozilla/5.0
2023-10-25 09:14:40,192.168.1.10,GET,/missing-page,404,210,Mozilla/5.0
2023-10-25 10:22:15,198.51.100.22,GET,/index.html,200,1024,Mozilla/5.0
2023-10-25 10:22:18,198.51.100.22,GET,/health,500,120,Mozilla/5.0
2023-10-25 14:05:00,203.0.113.88,GET,/index.html,200,1024,Mozilla/5.0
2023-10-25 14:05:12,203.0.113.88,GET,/student-portal,200,3200,Mozilla/5.0
2023-10-25 14:10:30,192.168.1.15,GET,/index.html,200,1024,Mozilla/5.0
2023-10-25 16:45:10,198.51.100.99,GET,/nonexistent,404,210,Mozilla/5.0
```

### Python Log Analysis Script (`analyze_logs.py`)
```python
#!/usr/bin/env python3
import csv
from collections import Counter
from datetime import datetime
import sys

def analyze_logs(filepath):
    ip_counter = Counter()
    path_counter = Counter()
    error_counter = Counter()
    hour_counter = Counter()
    total_requests = 0

    try:
        with open(filepath, mode='r', encoding='utf-8') as f:
            reader = csv.reader(f)
            for row in reader:
                if len(row) < 5:
                    continue
                timestamp, ip, method, path, status, size, agent = [x.strip() for x in row]
                total_requests += 1
                ip_counter[ip] += 1
                path_counter[path] += 1

                if status.isdigit() and 400 <= int(status) < 600:
                    error_counter[status] += 1

                try:
                    dt = datetime.strptime(timestamp.split('.')[0], "%Y-%m-%d %H:%M:%S")
                    hour_counter[dt.hour] += 1
                except ValueError:
                    pass
    except FileNotFoundError:
        print(f"File {filepath} not found.")
        sys.exit(1)

    print("=" * 60)
    print("         AWS WEB APPLICATION LOG ANALYTICS REPORT         ")
    print("=" * 60)
    print(f"Total Requests Analyzed: {total_requests}\n")

    print("1. Top Requested Pages:")
    for path, count in path_counter.most_common(5):
        print(f"   {path}: {count} requests")

    print("\n2. 4xx / 5xx Error Summary:")
    if error_counter:
        for code, count in sorted(error_counter.items()):
            print(f"   HTTP Status {code}: {count} occurrences")
    else:
        print("   No errors recorded.")

    print("\n3. Peak Traffic Hour:")
    peak_hour, peak_count = hour_counter.most_common(1)[0]
    print(f"   Hour {peak_hour:02d}:00 with {peak_count} requests")

    print("\n4. Unique Visitor IPs:")
    for ip, count in ip_counter.most_common(5):
        print(f"   IP: {ip} ({count} requests)")
    print("=" * 60)

if __name__ == "__main__":
    analyze_logs(sys.argv[1] if len(sys.argv) > 1 else "web-access-logs.csv")
```

---

## 7. CloudWatch Alarm Metrics Criteria

1. **CPU Utilization Alarm (`HighCPUUsage`):**
   * **Metric:** `CPUUtilization` (Namespace: `AWS/EC2`)
   * **Statistic:** Average
   * **Period:** 5 minutes
   * **Threshold:** Greater than `70%` for 2 consecutive periods.
   * **Action:** Send notification to SNS Topic (`arn:aws:sns:us-east-1:123456789012:CloudOpsAlerts`).

2. **Status Check Failure Alarm (`InstanceHealthCheck`):**
   * **Metric:** `StatusCheckFailed` (Namespace: `AWS/EC2`)
   * **Statistic:** Maximum
   * **Period:** 1 minute
   * **Threshold:** Greater than or equal to `1` (System or Instance check failure).
   * **Action:** Send notification to SNS Topic.

---

## 8. Free Tier Safety Checklist
- [ ] **Instance Type:** Verified `t3.micro` or `t2.micro` (running $< 750$ hours/month).
- [ ] **EBS Storage:** Root volume limited to $\le 30$ GB General Purpose SSD (gp2/gp3).
- [ ] **Snapshots:** Exactly 1 manual EBS snapshot created for testing and deleted after verification.
- [ ] **Networking:** No NAT Gateways, no Elastic Load Balancers (ALB), and no VPC Endpoints.
- [ ] **Budgets & Billing:** AWS Budget alert configured at $1.00 (forecasted) and $3.00 (actual) with SNS email triggers.

---

## 9. Four-Week Structured Project Timeline

```mermaid
gantt
    title AWS Internship Project Timeline
    dateFormat  YYYY-MM-DD
    section Phase 1 & 2
    Account Setup & IAM Policies       :active, p1, 2023-10-01, 7d
    Custom VPC & Networking Setup      :p2, after p1, 7d
    section Phase 3 & 4
    EC2 Web Application & User Data    :p3, after p2, 7d
    S3 Storage & EBS Backup Plan       :p4, after p3, 7d
    section Phase 5 & 6
    CloudWatch Alarms & SNS Alerts     :p5, after p4, 7d
    Log Dataset & Python Analytics     :p6, after p5, 7d
```

* **Week 1:** IAM Foundation, least-privilege policies, and custom VPC networking architecture.
* **Week 2:** EC2 deployment, Nginx configuration, web server validation, and `/health` endpoint setup.
* **Week 3:** S3 log synchronization, EBS backup and restoration procedures.
* **Week 4:** CloudWatch monitoring, SNS alerting, AWS Budgets setup, and Python log analysis execution.

---

## 10. Risk Mitigation Matrix

| Risk Hazard | Potential Impact | Mitigation Strategy |
| :--- | :--- | :--- |
| **Unexpected Charges** | Accidental deployment of non-Free Tier resources (e.g., NAT Gateway, t3.large). | Strictly adhere to the VPC architecture and configure AWS Budgets with $1/$3 email alerts. |
| **Open SSH Security Vulnerability** | Unauthorized access to EC2 via `0.0.0.0/0` on Port 22. | Restrict Security Group SSH inbound rules to your specific public IP address (`YOUR_IP/32`). |
| **Over-Permissioned IAM Roles** | Compromised EC2 instance granting full admin access to S3 or AWS account. | Enforce strict least-privilege IAM policies scoped to a single target S3 bucket. |
